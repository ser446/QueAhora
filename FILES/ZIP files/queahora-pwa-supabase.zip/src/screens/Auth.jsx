import {useState} from "react";
import * as auth from "../auth.js";

const okEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());
const TITLES = {
  login: ["Ingresá a tu cuenta", "Seguí con tu biblioteca"],
  register: ["Crear cuenta", "Sumate a QuéAhora?"],
  recover: ["Recuperar acceso", "Te ayudamos a volver a entrar"],
  reset: ["Nueva contraseña", "Elegí una contraseña nueva"]
};
const LABEL = {login: "Ingresar", register: "Crear cuenta", recover: "Enviarme el enlace", reset: "Guardar contraseña"};

export default function Auth({onAuth,recovery=false}){
 const [mode,setMode]=useState(recovery?"reset":"login");
 const [f,setF]=useState({name:"",email:"",pw:"",pw2:""});
 const [show,setShow]=useState(false);
 const [err,setErr]=useState("");
 const [info,setInfo]=useState("");
 const [sent,setSent]=useState(false);
 const [busy,setBusy]=useState(false);
 const set=k=>e=>{setF({...f,[k]:e.target.value});setErr("")};
 const to=(m,msg="")=>{setMode(m);setErr("");setInfo(msg);setSent(false);setF({...f,pw:"",pw2:""})};
 const run=async fn=>{setBusy(true);setErr("");try{await fn()}catch(e){setErr(e.message||"Ocurrió un error. Probá de nuevo.")}finally{setBusy(false)}};

 const submit=ev=>{
  ev.preventDefault();
  if(busy)return;
  if(!(mode==="reset"&&recovery)&&!okEmail(f.email))return setErr("Ingresá un correo válido.");
  if(mode==="login"){
   if(!f.pw)return setErr("Ingresá tu contraseña.");
   return run(async()=>onAuth(await auth.login(f.email,f.pw)));
  }
  if(mode==="recover")return run(async()=>{await auth.requestReset(f.email);setSent(true)});
  if(mode==="register"&&!f.name.trim())return setErr("Ingresá tu nombre.");
  if(f.pw.length<8)return setErr("La contraseña debe tener al menos 8 caracteres.");
  if(f.pw!==f.pw2)return setErr("Las contraseñas no coinciden.");
  if(mode==="register")return run(async()=>{const u=await auth.register({name:f.name,email:f.email,password:f.pw});if(u)onAuth(u);else to("login","Te enviamos un correo para confirmar tu cuenta. Confirmala y luego ingresá.")});
  return run(async()=>{const u=await auth.resetPassword(f.email,f.pw);if(u)onAuth(u);else to("login","Contraseña actualizada. Ya podés ingresar.")});
 };

 const pw=(key,label,auto)=><>
  <div className="label">{label}</div>
  <div className="pw"><input className="field" type={show?"text":"password"} autoComplete={auto} value={f[key]} onChange={set(key)} aria-label={label}/>
   <button type="button" className="link" onClick={()=>setShow(!show)}>{show?"Ocultar":"Mostrar"}</button></div>
 </>;

 return <>
  <div className="top"><small>QuéAhora? 📚</small><h2>{TITLES[mode][0]}</h2><small>{TITLES[mode][1]}</small></div>
  <div className="content">
   {info&&<p className="note" style={{color:"var(--teal)",fontWeight:600}} role="status">{info}</p>}
   {(mode==="login"||mode==="register")&&<>
    <button type="button" className="gbtn" disabled={busy} onClick={()=>run(async()=>{const u=await auth.loginWithGoogle();if(u)onAuth(u)})}><b>G</b> Continuar con Google</button>
    <div className="or">o con tu correo</div>
   </>}
   {mode==="recover"&&sent?<>
    <p className="note">Si el correo <b>{f.email}</b> tiene una cuenta, te enviamos un enlace para crear una contraseña nueva. Revisá también la carpeta de spam.</p>
    {auth.isDemo&&<>
     <p className="note">Modo demo: no se envió ningún correo real.</p>
     <button className="btn" onClick={()=>to("reset")}>Simular que abro el enlace</button>
    </>}
   </>:<form onSubmit={submit} noValidate>
    {mode==="recover"&&<p className="note">Ingresá el correo de tu cuenta y te enviamos un enlace para recuperar el acceso.</p>}
    {mode==="register"&&<><div className="label">Nombre</div><input className="field" autoComplete="name" value={f.name} onChange={set("name")} aria-label="Nombre"/></>}
    {!(mode==="reset"&&recovery)&&<><div className="label">Correo electrónico</div>
    <input className="field" type="email" inputMode="email" autoComplete="email" value={f.email} onChange={set("email")} readOnly={mode==="reset"} aria-label="Correo electrónico"/></>}
    {mode==="login"&&pw("pw","Contraseña","current-password")}
    {mode==="register"&&<>{pw("pw","Contraseña (mínimo 8 caracteres)","new-password")}{pw("pw2","Repetí la contraseña","new-password")}</>}
    {mode==="reset"&&<>{pw("pw","Nueva contraseña (mínimo 8 caracteres)","new-password")}{pw("pw2","Repetí la contraseña","new-password")}</>}
    {err&&<p className="err" role="alert">{err}</p>}
    <button className="btn" type="submit" disabled={busy}>{busy?"Un momento…":LABEL[mode]}</button>
    {mode==="login"&&<button type="button" className="link" style={{marginTop:8}} onClick={()=>to("recover")}>¿Olvidaste tu contraseña?</button>}
   </form>}
   <div style={{textAlign:"center",marginTop:14}}>
    {mode==="login"&&<><div className="note">¿No tenés cuenta?</div><button className="link" onClick={()=>to("register")}>Registrate</button></>}
    {mode==="register"&&<><div className="note">¿Ya tenés cuenta?</div><button className="link" onClick={()=>to("login")}>Ingresá</button></>}
    {(mode==="recover"||mode==="reset")&&!recovery&&<button className="link" onClick={()=>to("login")}>Volver a ingresar</button>}
   </div>
   {auth.isDemo&&<p className="note" style={{marginTop:14}}>Modo demo: las cuentas se guardan solo en este navegador y el botón de Google simula el ingreso.</p>}
  </div>
 </>;
}
