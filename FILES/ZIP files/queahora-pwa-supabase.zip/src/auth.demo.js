// AUTENTICACIÓN DE DEMOSTRACIÓN — se usa solo cuando NO hay claves de Supabase configuradas.
// Guarda las cuentas en localStorage: NO es seguro y NO debe usarse en producción.
// Tiene el mismo contrato que auth.supabase.js (ver auth.js).

const USERS = "qa-users", SESSION = "qa-session";
const rd = (k, d) => { try { const s = localStorage.getItem(k); return s ? JSON.parse(s) : d; } catch (e) { return d; } };
const wr = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
const norm = e => e.trim().toLowerCase();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
const pub = u => ({ id: u.id, name: u.name, email: u.email, provider: u.provider || "password" });
const delay = () => new Promise(r => setTimeout(r, 400));

async function hash(pw, salt) {
  if (!(globalThis.crypto && crypto.subtle)) return "plain:" + pw; // solo demo
  return hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + pw)));
}

export function currentUser() {
  const id = rd(SESSION, null);
  const u = Object.values(rd(USERS, {})).find(x => x.id === id);
  return u ? pub(u) : null;
}

export async function register({ name, email, password }) {
  await delay();
  const us = rd(USERS, {}), k = norm(email);
  if (us[k]) throw new Error("Ya existe una cuenta con ese correo.");
  const salt = Math.random().toString(36).slice(2);
  const u = { id: "u" + Date.now(), name: name.trim(), email: k, salt, hash: await hash(password, salt) };
  us[k] = u; wr(USERS, us); wr(SESSION, u.id);
  return pub(u);
}

export async function login(email, password) {
  await delay();
  const u = rd(USERS, {})[norm(email)];
  // Mensaje genérico: no revela si el correo existe
  if (!u || !u.hash || u.hash !== await hash(password, u.salt)) throw new Error("Correo o contraseña incorrectos.");
  wr(SESSION, u.id);
  return pub(u);
}

export async function loginWithGoogle() {
  await delay(); // En producción abre la ventana de Google
  const us = rd(USERS, {}), k = "usuario.google@demo.local";
  const u = us[k] || (us[k] = { id: "g" + Date.now(), name: "Usuario de Google", email: k, provider: "google" });
  wr(USERS, us); wr(SESSION, u.id);
  return pub(u);
}

// En producción envía un correo con un enlace y nunca revela si la cuenta existe
export async function requestReset(email) { await delay(); return true; }

export async function resetPassword(email, password) {
  await delay();
  const us = rd(USERS, {}), u = us[norm(email)];
  if (!u) throw new Error("No encontramos una cuenta con ese correo (solo demo).");
  u.salt = Math.random().toString(36).slice(2);
  u.hash = await hash(password, u.salt);
  wr(USERS, us);
  return null; // en el demo la persona vuelve a ingresar manualmente
}

export function logout() { wr(SESSION, null); }

export const getUser = async () => currentUser();
export function onAuthChange() { return () => {}; }
