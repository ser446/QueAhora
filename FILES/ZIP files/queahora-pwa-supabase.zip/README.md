# QuéAhora? · PWA (Vite + React)

Prototipo funcional de la app, listo para instalar en el celular como PWA.
Los datos (libros, lecturas, reseñas, perfil) se guardan **solo en el navegador** (localStorage).

## Requisitos
- Node.js 18 o superior

## Comandos
```bash
npm install        # instala dependencias
npm run dev        # desarrollo en http://localhost:5173
npm run build      # genera la carpeta dist/
npm run preview    # prueba la versión final (con service worker)
```

## Probar la instalación y el modo sin conexión
1. `npm run build` y luego `npm run preview`.
2. Abrí la URL en Chrome o Edge. Debería aparecer la opción «Instalar app».
3. Con la app abierta, cortá internet (o DevTools → Network → Offline) y recargá: sigue funcionando.

El service worker solo se activa en la versión de producción, no en `npm run dev`.

## Publicar
Subí el contenido de `dist/` a Netlify, Vercel, Firebase Hosting, Cloudflare Pages o GitHub Pages.
Una PWA necesita **HTTPS** (todos esos servicios lo incluyen). La app usa rutas relativas, así que funciona en un dominio o en una subcarpeta.
Al publicar cambios, subí el número de `CACHE` en `public/sw.js` (por ejemplo `queahora-v2`) para que los usuarios reciban la versión nueva.

## Estructura
```
public/            manifest, service worker e íconos
src/data.js        catálogo de ejemplo y constantes
src/ui.jsx         portada y estrellas
src/App.jsx        estado global y navegación
src/screens/       Home, Library, Search, Book, Log, Profile, AddBook, Moderation, EditProfile
```

## Qué es de ejemplo y qué falta para producción
- Catálogo de 5 libros ficticios + libros cargados a mano (solo visibles en este navegador).
- Moderación de reseñas: pantalla de demostración accesible desde Perfil; en producción debe ser un rol aparte.
- Puntos: 3 por libro leído y 2 por reseña aprobada (regla definida para el prototipo).
- Pendiente (requiere backend): base de datos compartida, moderación real, importación de bibliotecas y datos de Google Books u Open Library.

## Autenticación con Supabase
La app arranca en **modo demo** (cuentas locales en el navegador) hasta que configures Supabase. Con las claves cargadas, usa Supabase de verdad: ingreso con correo y contraseña, registro con confirmación por correo, recuperación de contraseña e ingreso con Google.

1. Creá un proyecto en [supabase.com](https://supabase.com).
2. En **Project Settings > API** copiá la *Project URL* y la clave pública (`sb_publishable_...`; si tu proyecto usa las claves anteriores, la `anon` también sirve). Copiá `.env.example` como `.env.local`, pegá los valores y reiniciá `npm run dev`. **Nunca** pongas en la app una clave secreta o `service_role`.
3. En **Authentication > URL Configuration**: poné como *Site URL* la dirección donde publicás la app y en *Redirect URLs* agregá `http://localhost:5173/**` y `https://TU-DOMINIO/**`. Sin esto, la confirmación de correo, la recuperación y Google no vuelven a la app.
4. **Correo y contraseña** viene activado. Recomendamos dejar la confirmación de correo encendida y exigir al menos 8 caracteres de contraseña. Si apagás la confirmación, quien se registra entra directo.
5. **Google**: en Google Cloud Console creá un *ID de cliente OAuth* de tipo «Aplicación web» (y configurá la pantalla de consentimiento). En *URI de redirección autorizados* pegá la URL de callback que Supabase muestra en **Authentication > Providers > Google** (formato `https://TU-PROYECTO.supabase.co/auth/v1/callback`). Copiá el Client ID y el Client Secret a ese mismo panel de Supabase y activá el proveedor.
6. **Correos**: el servicio de correo incluido en Supabase sirve para probar pero tiene límites. Para producción conectá un SMTP propio y traducí las plantillas en **Authentication > Email Templates**.
7. Al publicar, cargá las mismas variables `VITE_...` en tu hosting y volvé a generar el build (Vite las incorpora al compilar).

Todo el acceso pasa por `src/auth.js`, que elige entre `auth.supabase.js` y `auth.demo.js`.
